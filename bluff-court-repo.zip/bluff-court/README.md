# Bluff Court

A multiplayer social deduction game built on GenLayer. Players defend a shared claim, but one is secretly bluffing — and AI validators reach onchain consensus on who's lying.

Built for the GenLayer Foundation's [Mini-games for the Community](https://portal.genlayer.foundation/) mission.

## What makes it interesting

Bluff Court isn't just a game with blockchain stapled on. The consensus mechanism *is* the gameplay. There's no objectively correct answer to "is this defense genuine or a bluff?" — only consensus can fairly resolve it. Optimistic Democracy makes this possible without oracles, central authorities, or trusted referees.

The game cannot exist on a traditional smart contract. That's the point.

## Repository layout

| Folder | Contents |
|---|---|
| `contract/` | The Intelligent Contract source code and deployment info |
| `docs/` | Contract documentation and the published tutorial |
| `frontend/` | Web app for casual players (in development) |
| `screenshots/` | Test results and build documentation |

## Quick start (run the contract yourself)

1. Open [GenLayer Studio](https://studio.genlayer.com)
2. Create a new file called `bluff_court.py`
3. Copy contents from [`contract/bluff_court.py`](./contract/bluff_court.py) into it
4. Click Deploy
5. Call `start_round` → `submit` (5 times) → `judge_round` → `get_verdict`

Full walkthrough in [`docs/tutorial.md`](./docs/tutorial.md).

## Game flow

```
start_round("Pineapple belongs on pizza")
   ↓
submit("Pineapple's sweetness balances the salty cheese...")  [×5 players]
   ↓
judge_round()
   ↓
[GenLayer validators read all submissions, reach consensus]
   ↓
get_verdict() → "Liar identified: submission 5"
```

## Test results

Three rounds tested onchain with successful consensus:

1. **Obvious Liar** (cats-instead-of-pizza) — caught ✅
2. **Sneaky Liar** (pizza-dough but not pineapple) — caught ✅
3. **Dynamic round** (5 separate `submit` calls) — caught ✅

See [`screenshots/`](./screenshots/) for the FINALIZED transaction proofs.

## What's still in progress

- [ ] Frontend (Next.js + custodial backend so players don't need wallets)
- [ ] Random Liar selection in the contract
- [ ] Per-player tracking and leaderboard
- [ ] Random prompt rotation for weekly replayability

## Built for

The GenLayer Mini-games for Community mission, with an accompanying tutorial submitted to the Educational Content mission.

## License

MIT — see [LICENSE](./LICENSE).
