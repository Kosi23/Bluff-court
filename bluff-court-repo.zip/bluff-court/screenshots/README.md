# Screenshots

This folder holds the visual proof of the contract working onchain.

## What to add here

Suggested files to upload from your build sessions:

- `wizard-of-coin-success.png` — the Wizard returning `false` after persuasion
- `verdict-hardcoded-obvious.png` — first successful verdict on hardcoded Liar
- `verdict-hardcoded-sneaky.png` — verdict on the pizza-dough Liar
- `submissions-finalized.png` — list of FINALIZED submit transactions
- `verdict-dynamic.png` — final verdict from dynamic round
- `studio-deployed.png` — contract deployed status in Studio

These get referenced in the tutorial (`docs/tutorial.md`) and the README.
