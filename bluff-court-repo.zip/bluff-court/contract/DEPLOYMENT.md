# Deployment Information

## Current deployment

| Field | Value |
|---|---|
| Network | GenLayer Studionet |
| Address | `0x66...a647` *(replace with full address)* |
| Deployer | `0x5C...CE66` |
| Status | Active |

## Test history

All test transactions were FINALIZED successfully on Studionet.

### Test 1 — Hardcoded obvious Liar
- Setup: Five hardcoded submissions, Liar #5 talks about cats instead of pizza
- Result: Validators correctly identified submission 5
- Tx hash: *(add from Studio transaction history)*

### Test 2 — Hardcoded sneaky Liar
- Setup: Liar #5 discusses pizza dough technique, never mentions pineapple
- Result: Validators correctly identified submission 5
- Tx hash: *(add from Studio transaction history)*

### Test 3 — Dynamic submissions via `submit()`
- Setup: 5 separate `submit` transactions, then `judge_round`
- Result: Validators correctly identified submission 5
- Tx hashes:
  - judge_round: `0xb747...`
  - submits: `0x6533...`, `0xd2e6...`, etc.

## How to redeploy

1. Open https://studio.genlayer.com
2. Create or open `bluff_court.py`
3. Paste contents from `contract/bluff_court.py`
4. Click Deploy
5. Update the address above with the new deployment

## Moving to public testnet

For wider playtesting, redeploy to Asimov testnet:

- RPC: `https://rpc-asimov.genlayer.com`
- Chain ID: `4221`
- Faucet: https://testnet-faucet.genlayer.foundation
- Explorer: https://explorer-asimov.genlayer.com

Update this file when the redeployment is done.
