# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
from genlayer import *
import json


class BluffCourt(gl.Contract):
    """
    A multiplayer social deduction game on GenLayer.
    
    Players submit defenses to a shared claim. One player is secretly
    bluffing. LLM validators reach Optimistic Democracy consensus on
    which submission doesn't actually engage with the claim.
    """
    
    shared_prompt: str
    submissions: DynArray[str]
    round_active: bool
    last_verdict: str
    
    def __init__(self):
        self.shared_prompt = ""
        self.round_active = False
        self.last_verdict = "No round judged yet"
    
    @gl.public.write
    def start_round(self, prompt: str) -> None:
        """Begin a new round. Clears old submissions and sets the debate topic."""
        while len(self.submissions) > 0:
            self.submissions.pop()
        self.shared_prompt = prompt
        self.round_active = True
        self.last_verdict = "Round in progress, waiting for submissions"
    
    @gl.public.write
    def submit(self, defense: str) -> None:
        """Add a player's defense to the current round."""
        if not self.round_active:
            raise gl.vm.UserError("No active round. Call start_round first.")
        if len(self.submissions) >= 5:
            raise gl.vm.UserError("Round is full. 5 submissions already received.")
        self.submissions.append(defense)
    
    @gl.public.write
    def judge_round(self) -> None:
        """Send submissions to validators for Optimistic Democracy consensus."""
        if not self.round_active:
            raise gl.vm.UserError("No active round to judge.")
        if len(self.submissions) < 3:
            raise gl.vm.UserError("Need at least 3 submissions to judge.")
        
        numbered_subs = ""
        for i in range(len(self.submissions)):
            numbered_subs += f"{i+1}. {self.submissions[i]}\n"
        
        prompt = f"""
Players were each asked to defend the claim:
"{self.shared_prompt}"

One player secretly received a different prompt and is bluffing.
Read all submissions and identify which one does NOT actually engage 
with the claim and is therefore the Liar.

Submissions:
{numbered_subs}

Respond with just a JSON object like: {{"liar": <number>}}
"""
        
        def get_verdict():
            result = gl.nondet.exec_prompt(prompt)
            result = result.replace("```json", "").replace("```", "")
            return result
        
        result = gl.eq_principle.prompt_comparative(
            get_verdict, 
            "The liar number must match"
        )
        
        parsed = json.loads(result)
        self.last_verdict = f"Liar identified: submission {parsed['liar']}"
        self.round_active = False
    
    @gl.public.view
    def get_verdict(self) -> str:
        """Return the result of the last judged round."""
        return self.last_verdict
    
    @gl.public.view
    def get_submission_count(self) -> int:
        """Return how many submissions have been received this round."""
        return len(self.submissions)
    
    @gl.public.view
    def get_prompt(self) -> str:
        """Return the current debate topic."""
        return self.shared_prompt
