# Building Bluff Court on GenLayer: A Beginner's Walkthrough to Onchain Social Deduction

I started this build calling myself a newbie. Two sessions later, I had a working multiplayer game where AI validators reach onchain consensus on who's lying. This is the walkthrough I wish existed when I started.

If you've heard of GenLayer but never written an Intelligent Contract, this tutorial is for you. We'll build Bluff Court — a social deduction game where players submit defenses to a shared prompt, but one player is secretly bluffing. Multiple LLMs running independently then reach consensus on who's lying, with the verdict recorded onchain.

No local setup required. No Docker. No CLI struggles. Just a browser and roughly two hours.

## What makes this possible (and why traditional smart contracts can't do it)

A regular smart contract on Ethereum can verify math, transfer tokens, and execute deterministic logic. It cannot read a paragraph of text and decide whether the author is bluffing. That's a subjective judgment — there's no objective "true" answer to compute against.

GenLayer solves this through Optimistic Democracy. Multiple validators, each running different LLMs, independently evaluate the same input and reach consensus. The result lands onchain with the same finality as any blockchain transaction.

For Bluff Court, this is the entire game. Without consensus on subjective judgment, there's no way to fairly resolve "is this defense genuine or a bluff?" The mechanic only exists because GenLayer exists.

> **[SCREENSHOT 1: Final verdict screen showing "Liar identified: submission 5"]**

## What we're building

Five players join a round. They all see the same prompt — say, *"Pineapple belongs on pizza."* Four players defend it honestly. One player is the Liar — they were given a different prompt or are deliberately off-topic.

After all submissions are in, the Intelligent Contract sends them to the GenLayer validator network. The validators read each defense and reach consensus on which one doesn't actually engage with the claim. The verdict is recorded onchain.

That's the core mechanic. Everything else — XP, leaderboards, frontends — builds on top of this foundation.

## Step 1: Setup (5 minutes)

Skip the local installation rabbit hole. Go straight to **studio.genlayer.com**. It's a hosted IDE with everything pre-installed. Connect a wallet (the built-in option works fine), then click the water drop icon next to your account to fund it from the faucet.

You're now ready to write contracts. No Docker, no validators to configure, no environment variables.

## Step 2: Read the Wizard of Coin example first

Don't write your own contract yet. In the file sidebar of Studio, find `wizard_of_coin.py`. Open it.

This 30-line example is the closest existing pattern to what we're building. It shows an LLM being asked to make a subjective decision (should the wizard give up the coin?) and the validators reaching consensus on the answer.

Deploy it. Call `ask_for_coin` with a request like *"I am the rightful owner of this coin."* Wait for the transaction to finalize. Then call `get_has_coin` and watch the boolean change based on whether the LLM was convinced.

> **[SCREENSHOT 2: Wizard of Coin returning `false` after successful persuasion]**

This isn't busywork. Understanding this example will make the next part click immediately.

## Step 3: Build the simplest possible bluff detector

Create a new file in Studio called `bluff_court.py`. Paste in this minimal version:

```python
# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
from genlayer import *
import json

class BluffCourt(gl.Contract):
    last_verdict: str
    
    def __init__(self):
        self.last_verdict = "No round judged yet"
    
    @gl.public.write
    def judge_round(self) -> None:
        prompt = """
Five players were each asked to defend the claim:
"Pineapple belongs on pizza"

One player secretly received a different prompt and is bluffing.
Read all five submissions and identify which one (1-5) does NOT 
actually engage with the pizza claim and is therefore the Liar.

Submissions:
1. Pineapple adds sweetness that balances the salty cheese and savory ham. It's a classic combo.
2. The acidity of pineapple cuts through the fat of cheese, making each bite more refreshing.
3. Hawaiian pizza is one of the most popular pizzas globally for a reason — the contrast works.
4. Cooking pineapple changes its texture and concentrates the flavor in a way that complements pizza dough.
5. Cats solve problems independently and don't need constant validation. Their reasoning is just different from dogs.

Respond with just a JSON object like: {"liar": 5}
"""
        
        def get_verdict():
            result = gl.nondet.exec_prompt(prompt)
            result = result.replace("```json", "").replace("```", "")
            return result
        
        result = gl.eq_principle.prompt_comparative(
            get_verdict, 
            "The liar number must match"
        )
        
        parsed = json.loads(result)
        self.last_verdict = f"Liar identified: submission {parsed['liar']}"
    
    @gl.public.view
    def get_verdict(self) -> str:
        return self.last_verdict
```

The submissions are hardcoded for now. We're testing whether the validators can spot the obvious Liar (the cats one) before adding any complexity.

Deploy the contract. Make sure Simulation Mode is OFF — that's important. Simulation mode pretends to run the transaction without actually doing it, which is useful for debugging but won't actually reach validator consensus. Click `judge_round`, then `get_verdict`.

If everything worked, you'll see: *"Liar identified: submission 5"*

> **[SCREENSHOT 3: First successful verdict on hardcoded version]**

The validators caught it. Five hardcoded submissions, four about pineapple, one about cats — and the LLMs unanimously agreed which one didn't belong.

## Step 4: Test with a sneakier Liar

The cats submission was easy. Anyone could spot that. The real question is whether validators can reason about subtler bluffs.

Replace submission 5 with this:

```
5. Pizza dough is best when made with a 24-hour cold fermentation. The Maillard reaction during baking creates that perfect crust we all love.
```

This Liar is talking about pizza. They sound knowledgeable. They use technical terms. But they never actually defend pineapple specifically.

Redeploy. Run `judge_round` again. Read the verdict.

> **[SCREENSHOT 4: Verdict on sneaky Liar version, still correctly identifying submission 5]**

Still caught. The validators reasoned that despite being pizza-related, the submission failed to engage with the actual claim. This is the moment I realized GenLayer wasn't just running keyword matching — the LLMs were doing genuine reasoning about subjective fit.

This is also the part where prompt engineering matters. Most of the work in building Bluff Court isn't the contract logic — it's tuning that validator prompt until subtle bluffs get caught reliably.

## Step 5: Make it actually playable with dynamic submissions

The hardcoded version proved the concept. Now we make it a real game where players submit their own defenses.

Replace your contract with this fuller version:

```python
# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
from genlayer import *
import json

class BluffCourt(gl.Contract):
    shared_prompt: str
    submissions: DynArray[str]
    round_active: bool
    last_verdict: str
    
    def __init__(self):
        self.shared_prompt = ""
        self.round_active = False
        self.last_verdict = "No round judged yet"
    
    @gl.public.write
    def start_round(self, prompt: str) -> None:
        while len(self.submissions) > 0:
            self.submissions.pop()
        self.shared_prompt = prompt
        self.round_active = True
        self.last_verdict = "Round in progress, waiting for submissions"
    
    @gl.public.write
    def submit(self, defense: str) -> None:
        if not self.round_active:
            raise gl.vm.UserError("No active round. Call start_round first.")
        if len(self.submissions) >= 5:
            raise gl.vm.UserError("Round is full. 5 submissions already received.")
        self.submissions.append(defense)
    
    @gl.public.write
    def judge_round(self) -> None:
        if not self.round_active:
            raise gl.vm.UserError("No active round to judge.")
        if len(self.submissions) < 3:
            raise gl.vm.UserError("Need at least 3 submissions to judge.")
        
        numbered_subs = ""
        for i in range(len(self.submissions)):
            numbered_subs += f"{i+1}. {self.submissions[i]}\n"
        
        prompt = f"""
Players were each asked to defend the claim:
"{self.shared_prompt}"

One player secretly received a different prompt and is bluffing.
Read all submissions and identify which one does NOT actually engage 
with the claim and is therefore the Liar.

Submissions:
{numbered_subs}

Respond with just a JSON object like: {{"liar": <number>}}
"""
        
        def get_verdict():
            result = gl.nondet.exec_prompt(prompt)
            result = result.replace("```json", "").replace("```", "")
            return result
        
        result = gl.eq_principle.prompt_comparative(
            get_verdict, 
            "The liar number must match"
        )
        
        parsed = json.loads(result)
        self.last_verdict = f"Liar identified: submission {parsed['liar']}"
        self.round_active = False
    
    @gl.public.view
    def get_verdict(self) -> str:
        return self.last_verdict
    
    @gl.public.view
    def get_submission_count(self) -> int:
        return len(self.submissions)
    
    @gl.public.view
    def get_prompt(self) -> str:
        return self.shared_prompt
```

What changed:
- Submissions are now stored in `DynArray[str]` instead of hardcoded
- `start_round(prompt)` sets the debate topic and resets state
- `submit(defense)` lets players add their defenses one at a time
- `judge_round()` builds the validator prompt from stored data

Deploy this fresh version. Now play through a full round:

1. Call `start_round` with the prompt: *"Pineapple belongs on pizza"*
2. Call `submit` five times with five different defenses (four honest, one Liar)
3. Call `judge_round`
4. Read `get_verdict`

Each submit is a separate transaction. You'll wait for finalization between each one. Patience required, but this is exactly what real gameplay looks like.

> **[SCREENSHOT 5: List of FINALIZED submit transactions in the Studio sidebar]**

> **[SCREENSHOT 6: Final dynamic verdict, "Liar identified: submission 5"]**

## Common pitfalls I hit

Three traps cost me time. Save yourself the same:

**Confusing `start_round` with `submit`.** I once typed a player's defense into the `start_round` prompt field, then realized I'd just made the bluff sentence the debate topic. The `start_round` parameter is the *shared prompt* (what everyone is supposedly defending). The `submit` parameter is a *player's defense*. Easy to mix up early on.

**Leaving Simulation Mode on.** Studio has a checkbox that runs transactions in simulation rather than actually executing them. This is great for debugging logic, but if you're trying to test the full validator consensus flow, simulation mode will give you `null` results and confusion. Toggle it off when you want real onchain execution.

**Trying to redeploy without saving.** If you edit the contract code in Studio and click Deploy without first saving the file (Cmd+S), you might deploy the previous version. Save first, deploy second.

## What's next

What you have now is a working game *contract*. To make it a playable game, you still need:

- A frontend so players don't need to use the Studio debug UI
- Some way to assign the Liar role randomly (currently whoever calls `start_round` decides)
- Player tracking, XP, and a leaderboard

I'm building the frontend next as a Next.js + custodial backend setup, so casual players can join without needing wallets or testnet tokens. The contract stays the same.

But here's the thing: even at this stage, you've built something genuinely impressive. A multiplayer game where AI validators make subjective judgments through onchain consensus, deployed and tested. That's not a small thing. That's the entire premise of GenLayer working in your hands.

## Why this approach generalizes

Bluff Court is one game, but the pattern works for anything subjective:

- **Caption contests** judged by validator consensus on humor
- **Debate scoring** where AIs evaluate argument quality
- **Content moderation** with no central authority
- **Peer review** for academic submissions or code reviews
- **Hot take markets** where the spiciness of an opinion is itself the asset

If you can describe the judgment criteria clearly enough for an LLM to follow, GenLayer can decentralize that judgment. That's the unlock.

---

The full contract source, deployment details, and test results are in my [contract documentation file](LINK_TO_DOCS). The repo will go up once the frontend is ready. If you want to chat about Intelligent Contracts or share what you're building on GenLayer, I'm @yourhandle on X.

Build something subjective. Let the validators reach consensus.
