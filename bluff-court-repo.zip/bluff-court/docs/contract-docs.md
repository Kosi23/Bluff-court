# Bluff Court — Contract Documentation

A multiplayer social deduction game built as an Intelligent Contract on GenLayer. Players submit defenses to a shared prompt, but one player secretly receives a different prompt and is bluffing. AI validators reach consensus through Optimistic Democracy to identify the Liar.

## Deployment Info

| Field | Value |
|---|---|
| Contract name | `BluffCourt` |
| File | `bluff_court.py` |
| Network | GenLayer Studionet (will redeploy to Asimov testnet for production) |
| Deployed address | `0x66...a647` *(replace with full address from Studio)* |
| Language | Python (Intelligent Contract) |
| Consensus method | Optimistic Democracy via `eq_principle.prompt_comparative` |

## What This Contract Does

Bluff Court runs a single round of social deduction:

1. A round starts with a shared debate prompt (e.g., *"Pineapple belongs on pizza"*)
2. Up to five players submit written defenses
3. One of those submissions is secretly the Liar — they were given a different prompt or are deliberately off-topic
4. The contract sends all submissions to LLM validators with instructions to identify the Liar
5. Validators independently reach consensus on which submission doesn't actually defend the claim
6. The verdict is recorded onchain

The contract showcases what Intelligent Contracts can do that traditional smart contracts cannot: make subjective judgments through AI consensus, with no oracle or centralized arbiter.

## State Variables

| Variable | Type | Purpose |
|---|---|---|
| `shared_prompt` | `str` | The debate topic everyone is supposedly defending |
| `submissions` | `DynArray[str]` | List of all submitted defenses for the current round |
| `round_active` | `bool` | Whether a round is currently accepting submissions |
| `last_verdict` | `str` | Human-readable result of the last judged round |

## Functions

### Write Methods (require transactions)

#### `start_round(prompt: str)`

Starts a new round. Clears any previous submissions and sets the debate topic.

**Parameters:** `prompt` — the claim players will defend (or appear to defend)

**Effect:**
- Empties the submissions array
- Sets `shared_prompt` to the new prompt
- Sets `round_active` to `True`
- Resets `last_verdict` to indicate round is in progress

**Example call:**
```
start_round("Pineapple belongs on pizza")
```

---

#### `submit(defense: str)`

Adds a player's defense to the current round.

**Parameters:** `defense` — the text the player is submitting

**Validation:**
- Throws `UserError` if no round is active
- Throws `UserError` if 5 submissions are already received

**Effect:** Appends the defense to the submissions array

**Example call:**
```
submit("Pineapple adds sweetness that balances the salty cheese.")
```

---

#### `judge_round()`

Sends all submissions to LLM validators and records their consensus on who the Liar is.

**Parameters:** None

**Validation:**
- Throws `UserError` if no round is active
- Throws `UserError` if fewer than 3 submissions exist

**Effect:**
1. Builds a prompt for the validators including the shared topic and all numbered submissions
2. Calls `gl.eq_principle.prompt_comparative` to run multiple validators
3. Validators independently identify which submission doesn't defend the claim
4. Consensus result is parsed and stored in `last_verdict`
5. Sets `round_active` to `False`

**The validator prompt:**
```
Players were each asked to defend the claim:
"{shared_prompt}"

One player secretly received a different prompt and is bluffing.
Read all submissions and identify which one does NOT actually engage 
with the claim and is therefore the Liar.

Submissions:
1. {submission 1}
2. {submission 2}
...

Respond with just a JSON object like: {"liar": <number>}
```

**Equivalence Principle used:** `prompt_comparative` with the criterion *"The liar number must match"* — meaning all validators must agree on the same submission number for consensus to be reached.

---

### Read Methods (no transaction, free)

#### `get_verdict() -> str`
Returns the human-readable result of the last judged round.

**Possible return values:**
- `"No round judged yet"` — initial state
- `"Round in progress, waiting for submissions"` — round is active, not yet judged
- `"Liar identified: submission N"` — round is complete, validators picked submission N

#### `get_submission_count() -> int`
Returns how many submissions have been received in the current round.

#### `get_prompt() -> str`
Returns the current debate topic.

## Test Results

The contract has been tested across multiple scenarios on GenLayer Studionet. All tests reached `FINALIZED` status with successful consensus.

### Test 1: Hardcoded obvious Liar

**Setup:** Five hardcoded submissions, the Liar (#5) discusses cats instead of pizza.

**Submissions:**
1. *"Pineapple adds sweetness that balances the salty cheese and savory ham. It's a classic combo."*
2. *"The acidity of pineapple cuts through the fat of cheese, making each bite more refreshing."*
3. *"Hawaiian pizza is one of the most popular pizzas globally for a reason — the contrast works."*
4. *"Cooking pineapple changes its texture and concentrates the flavor in a way that complements pizza dough."*
5. *"Cats solve problems independently and don't need constant validation. Their reasoning is just different from dogs."*

**Result:** ✅ Validators correctly identified submission 5 as the Liar.

### Test 2: Hardcoded sneaky Liar (pizza-adjacent but not pineapple)

**Setup:** Liar (#5) talks about pizza dough technique, never mentions pineapple. Designed to test whether validators just match keywords or actually reason about the prompt.

**Liar submission:** *"Pizza dough is best when made with a 24-hour cold fermentation. The Maillard reaction during baking creates that perfect crust we all love."*

**Result:** ✅ Validators correctly identified submission 5. The LLMs reasoned that despite being pizza-related, the submission never defends pineapple specifically.

### Test 3: Dynamic submissions via individual `submit()` calls

**Setup:** Same content as Test 1 but submissions added one at a time through the `submit()` function rather than hardcoded. Each submission was a separate onchain transaction. Validators were then asked to judge the stored submissions.

**Result:** ✅ Validators correctly identified submission 5. Confirmed the contract works end-to-end with real player flow (start_round → submit × 5 → judge_round → get_verdict).

## Why This Works for the Mission

The mission brief asks for games that *"showcase GenLayer's Intelligent Contract and Optimistic Democracy consensus."* Bluff Court doesn't just include consensus as a feature — consensus IS the gameplay. Without Optimistic Democracy, there's no way to fairly resolve "is this defense bluffing or genuine?" The game cannot exist on a traditional smart contract.

The brief also requires:
- **Multiplayer / in rooms** — supports up to 5 players per round
- **5-15 minute duration** — round resolution takes ~1-2 minutes; full session with submission time fits comfortably
- **Replayable weekly** — prompt rotation provides infinite content variation
- **Leaderboard for XP** — planned addition (per-player tracking via address signatures)

## Known Limitations / TODO

- **Liar selection is currently manual.** Whoever calls `start_round` decides the prompt; players don't know who the Liar is supposed to be because there's no per-player private prompt distribution yet. Next iteration will randomly assign a Liar index and send that player a different prompt.
- **No player identity tracking.** Submissions are anonymous and there's no way yet to attribute defenses to specific players or track per-player win/loss records.
- **No XP or leaderboard logic in the contract.** This will be added once player tracking exists.
- **No frontend yet.** Players currently interact through GenLayer Studio's debug UI. Frontend is in development as a Next.js + custodial backend setup so casual players can join without needing wallets.

## Full Contract Code

```python
# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
from genlayer import *
import json

class BluffCourt(gl.Contract):
    shared_prompt: str
    submissions: DynArray[str]
    round_active: bool
    last_verdict: str
    
    def __init__(self):
        self.shared_prompt = ""
        self.round_active = False
        self.last_verdict = "No round judged yet"
    
    @gl.public.write
    def start_round(self, prompt: str) -> None:
        while len(self.submissions) > 0:
            self.submissions.pop()
        self.shared_prompt = prompt
        self.round_active = True
        self.last_verdict = "Round in progress, waiting for submissions"
    
    @gl.public.write
    def submit(self, defense: str) -> None:
        if not self.round_active:
            raise gl.vm.UserError("No active round. Call start_round first.")
        if len(self.submissions) >= 5:
            raise gl.vm.UserError("Round is full. 5 submissions already received.")
        self.submissions.append(defense)
    
    @gl.public.write
    def judge_round(self) -> None:
        if not self.round_active:
            raise gl.vm.UserError("No active round to judge.")
        if len(self.submissions) < 3:
            raise gl.vm.UserError("Need at least 3 submissions to judge.")
        
        numbered_subs = ""
        for i in range(len(self.submissions)):
            numbered_subs += f"{i+1}. {self.submissions[i]}\n"
        
        prompt = f"""
Players were each asked to defend the claim:
"{self.shared_prompt}"

One player secretly received a different prompt and is bluffing.
Read all submissions and identify which one does NOT actually engage 
with the claim and is therefore the Liar.

Submissions:
{numbered_subs}

Respond with just a JSON object like: {{"liar": <number>}}
"""
        
        def get_verdict():
            result = gl.nondet.exec_prompt(prompt)
            result = result.replace("```json", "").replace("```", "")
            return result
        
        result = gl.eq_principle.prompt_comparative(
            get_verdict, 
            "The liar number must match"
        )
        
        parsed = json.loads(result)
        self.last_verdict = f"Liar identified: submission {parsed['liar']}"
        self.round_active = False
    
    @gl.public.view
    def get_verdict(self) -> str:
        return self.last_verdict
    
    @gl.public.view
    def get_submission_count(self) -> int:
        return len(self.submissions)
    
    @gl.public.view
    def get_prompt(self) -> str:
        return self.shared_prompt
```
