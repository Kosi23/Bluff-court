# Frontend (Coming Soon)

The web app for casual players who want to join Bluff Court without setting up a wallet or acquiring testnet tokens.

## Architecture

- **Frontend:** Next.js + TypeScript + Tailwind, deployed on Vercel
- **Backend:** Node.js custodial server that holds one wallet and signs transactions on behalf of players
- **Database:** SQLite (or Postgres in production) for usernames and XP
- **Auth:** Simple username — no wallet required

The custodial design is intentional. Forcing every casual player to install MetaMask, add GenLayer testnet, and visit a faucet would lose 90% of users before they ever submit a defense. The contract logic and consensus stay 100% onchain — players just don't have to handle the crypto plumbing themselves.

## Status

In development. Contract is fully working; frontend wiring is next.
